from rest_framework import serializers
from .models import APIKey

class APIKeySerializer(serializers.ModelSerializer):
    class Meta:
        model = APIKey
        fields = ['admin', 'name', 'login', 'email', 'api_key', 'status', 'expired']
        