from django.utils import timezone
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import APIKey
from .serializers import APIKeySerializer
import hashlib,json
import datetime
def generate_short_api_key(email, length=30):
    hash_object = hashlib.sha256(email.encode())
    return hash_object.hexdigest()[:length]
@api_view(['POST'])
def register_api_key(request):
    data = request.data
    email = data.get('email', None)
    name = data.get('name', None)
    api_key = data.get('api_key', None)
    login = data.get('login', None)
    if APIKey.objects.filter(email=email).exists():
        return Response({'status': False, 'description': 'Email dan API key telah terdaftar'}, status=status.HTTP_400_BAD_REQUEST)
    else:
      if email and name and login:
        if api_key:pass
        else:api_key=generate_short_api_key(email)
        api_key_obj = APIKey(
        admin=False,
        name=name,
        login=login, 
        email=email, 
        api_key=api_key, 
        status=False, 
        expired=datetime.datetime.now().strftime("%d-%m-%Y")
        )
        api_key_obj.save()
        serializer = APIKeySerializer(api_key_obj)
        respon={'success':True,'data':serializer.data}
        return Response(respon, status=status.HTTP_201_CREATED)
      else:
        return Response({'success': False, 'description': 'data user di perlukan'}, status=status.HTTP_400_BAD_REQUEST)
@api_view(['POST'])
def register_api_key_admin(request):
    data = request.data
    email = data.get('email', None)
    name = data.get('name', None)
    api_key = data.get('api_key', None)
    login = data.get('login', None)
    if APIKey.objects.filter(admin=True).exists():
        return Response({'status': False, 'description': 'Sudah ada admin yang terdaftar'}, status=status.HTTP_400_BAD_REQUEST)
    else:
      if email and name and login:
        if api_key:pass
        else:api_key=generate_short_api_key(email)
        api_key_obj = APIKey(
        admin=True,
        name=name,
        login=login, 
        email=email, 
        api_key=api_key, 
        status=True, 
        expired='01-12-9999'
        )
        api_key_obj.save()
        serializer = APIKeySerializer(api_key_obj)
        respon={'success':True,'data':serializer.data}
        return Response(respon, status=status.HTTP_201_CREATED)
      else:
        return Response({'success': False, 'description': 'data user di perlukan'}, status=status.HTTP_400_BAD_REQUEST)
def update(api_key):
  api_key_obj = APIKey.objects.get(api_key=api_key)
  expired_date = datetime.datetime.strptime(api_key_obj.expired, "%d-%m-%Y").date()
  current_date = datetime.datetime.now().date()
  if current_date > expired_date:
      api_key_obj.status = False
      api_key_obj.save()
@api_view(['POST'])
def check_api_key(request):
    data = request.data
    try:
        if 'api_key' in data:
          api_key = data.get('api_key', None)
          update(api_key)
          api_key_obj = APIKey.objects.get(api_key=api_key)
          serializer = APIKeySerializer(api_key_obj)
          respon={'status':True,'data':serializer.data}
          return Response(respon)
        else:
          return Response({'success': False, 'description': 'data user di perlukan'}, status=status.HTTP_400_BAD_REQUEST)
    except APIKey.DoesNotExist:
        return Response({'status': False, 'description': 'Data user tidak ditemukan'}, status=status.HTTP_404_NOT_FOUND)
@api_view(['POST'])
def get_list(request):
  data=request.data
  if 'api_key' in data:
    api_key_obj = APIKey.objects.get(api_key=data.get('api_key', None))
    serializer = APIKeySerializer(api_key_obj).data['admin']
    if serializer == True:
      all_api_keys = APIKey.objects.all()
      data_=[]
      for data in all_api_keys:
        serialize = APIKeySerializer(data).data
        data_.append(serialize)
      respon={'status':True,'data':data_}
      return Response(respon)
    else:
      return Response({'success': False, 'description': 'maaf kamu tidak memiliki akses'}, status=status.HTTP_400_BAD_REQUEST)
@api_view(['POST'])
def update_user(request):
  data=request.data
  api_key_obj = APIKey.objects.get(api_key=data.get('api_admin', None))
  cek = APIKeySerializer(api_key_obj).data['admin']
  if cek:
    api_key_obj = APIKey.objects.get(email=data.get('user_update', None))
    api_key_obj.status = data['edit']['status']
    api_key_obj.expired = data['edit']['expired']
    api_key_obj.save()
    respon={'status':True,'data':'sukses update data user'}
    return Response(respon)
  else:
    return Response({'success': False, 'description': 'maaf kamu tidak memiliki akses'}, status=status.HTTP_400_BAD_REQUEST)
  return Response(data)