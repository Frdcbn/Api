from django.db import models
from django.utils import timezone
class APIKey(models.Model):
    admin = models.BooleanField(default=True)
    name = models.CharField(max_length=100)
    login = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    api_key = models.CharField(max_length=100, unique=True)
    status = models.BooleanField(default=True)
    expired = models.CharField(max_length=100)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
    def __str__(self):
        return self.email

    class Meta:
        db_table = 'api_key'  # Specify the custom table name
