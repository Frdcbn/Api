from django.urls import path
from user_api import views
from django.contrib import admin
urlpatterns = [
    path('admin/', admin.site.urls),
    path('regis/', views.register_api_key, name='register_api_key'),
    path('regis_admin/', views.register_api_key_admin, name='register_api_key_admin'),
    path('check/', views.check_api_key, name='check_api_key'),
    path('get_list/', views.get_list, name='get_list_user'),
    path('update_user/', views.update_user, name='update_user'),
]
